def contador():
    contador_letras = {}
    frase = input('Digite uma frase, palavra ou texto nesse espaço: ')

    for letra in frase:
        if letra in contador_letras:
            contador_letras[letra] += 1
        else: 
            contador_letras[letra] = 1

    lista_tuplas = list(contador_letras.items())
    return lista_tuplas,sum(contador_letras.values())

def ordenando_lista(lista_tuplas):
    lista_tuplas.sort(key=lambda x: x[1], reverse=True)
    return lista_tuplas[:2]  


def porcentagem(contagem,total):
     return (contagem * 100) / total


def main():
    lista_tuplas,total_letras = contador()  
    top_letras = ordenando_lista(lista_tuplas)  
    
   
    for letra, contagem in top_letras:
        frequencia = porcentagem(contagem,total_letras)
        
        
        print(f"A letra '{letra}' aparece {frequencia}% das vezes.")

if __name__ == "__main__":
    main()
