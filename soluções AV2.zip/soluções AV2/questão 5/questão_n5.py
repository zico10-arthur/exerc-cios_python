import csv
from datetime import datetime

# Função para converter o horário 'YYYY-MM-DD HH:MM:SS' em um número decimal de minutos
def horario_para_minutos(horario):
    try:
        # Converter o horário para um objeto datetime
        hora = datetime.strptime(horario, '%Y-%m-%d %H:%M:%S')
        # Converter para minutos decimais
        minutos = hora.hour * 60 + hora.minute + hora.second / 60
        return minutos
    except ValueError as e:
        # Caso não consiga converter, imprime o erro e retorna None
        print(f"Erro ao converter o horário {horario}: {e}")
        return None
def calcular_moda(diferencas):
    contagem = {}
    for diferenca in diferencas:
        if diferenca in contagem:
            contagem[diferenca] += 1
        else:
            contagem[diferenca] = 1
    max_frequencia = max(contagem.values())
    
    modas = [d for d, f in contagem.items() if f == max_frequencia]
    return modas, max_frequencia

def media():
    # Lê o arquivo CSV
    with open('questão5/questao5_trabalho_av2_atendimentos.csv', 'r', newline='') as file:
        reader = csv.reader(file)
        dados = [linha for linha in reader]

        # Verificando as primeiras linhas para garantir que o cabeçalho e os dados estão corretos
        print("Primeiras linhas do arquivo CSV:")
        for linha in dados[:5]:  # Mostra as primeiras 5 linhas
            print(linha)

        cabecalho = dados[0]  # Cabeçalho na primeira linha
        print(f"\nCabeçalho: {cabecalho}")

        # Verificando os índices das colunas
        indice_coluna1 = cabecalho.index('inicio')  # Índice da coluna 'inicio'
        indice_coluna2 = cabecalho.index('fim')    # Índice da coluna 'fim'
        print(f"Índice da coluna 'inicio': {indice_coluna1}, Índice da coluna 'fim': {indice_coluna2}")

        valores_coluna1 = []  # Para armazenar os horários de 'inicio' em formato decimal
        valores_coluna2 = []  # Para armazenar os horários de 'fim' em formato decimal

        # Iterar pelas linhas do CSV (exceto o cabeçalho)
        for linha in dados[1:]:
            horario1 = linha[indice_coluna1]  # Valor de 'inicio'
            horario2 = linha[indice_coluna2]  # Valor de 'fim'
            
            # Verificando o formato dos horários
            print(f"Processando: inicio = {horario1}, fim = {horario2}")

            # Converter os horários para minutos decimais
            horario1_minutos = horario_para_minutos(horario1)
            horario2_minutos = horario_para_minutos(horario2)
            
            if horario1_minutos is not None and horario2_minutos is not None:
                print(f"Inicio (minutos): {horario1_minutos}, Fim (minutos): {horario2_minutos}")
                valores_coluna1.append(horario1_minutos)
                valores_coluna2.append(horario2_minutos)
            else:
                print(f"Erro ao processar linha: {linha}")
        
        # Calcular a diferença entre os horários em minutos
        if len(valores_coluna1) > 0 and len(valores_coluna2) > 0:
            diferencas = []
            
            # Garantir que fim seja sempre maior que inicio, ajustando para passar da meia-noite
            for inicio, fim in zip(valores_coluna1, valores_coluna2):
                if fim < inicio:
                    # Se o horário de fim for menor que o de inicio, adicionar 1440 minutos (24 horas)
                    fim += 1440  # Adiciona 24 horas (1440 minutos)
                diferencas.append(fim - inicio)
            
            # Calcular a média das diferenças em minutos
            if len(diferencas) > 0:  # Verifica se há pelo menos uma diferença calculada
                media_minutos = sum(diferencas) / len(diferencas)
                print(f'\nA média das diferenças de horários é: {media_minutos:.2f} minutos')

                # Calcular a diferença máxima
                diferenca_maxima = max(diferencas)
                print(f'A diferença máxima entre os horários é: {diferenca_maxima:.2f} minutos')

                # Calcular a diferença mínima
                diferenca_minima = min(diferencas)
                print(f'A consulta de menor tempo foi: {diferenca_minima:.2f} minutos')


                modas, frequencia = calcular_moda(diferencas)
                if len(modas) == 1:
                    print(f'A moda é {modas[0]:.2f} minutos, que ocorre {frequencia} vezes.')
                else:
                    print(f'A moda é composta pelos valores: {", ".join([f"{m:.2f}" for m in modas])}, que ocorrem {frequencia} vezes.')
            else:
                print("Não foi possível calcular a média, pois não há diferenças válidas.")
        else:
            print("Não foi possível processar dados válidos para cálculo.")

# Chamar a função
media()
