def extrair_mensagem(cadeia):
    i = 0
    mensagem = ""
    
    while i < len(cadeia):
      
        freq_str = ""
        
        
        while i < len(cadeia) and cadeia[i].isdigit():
            freq_str += cadeia[i]
            i += 1
        
        
        if freq_str:
            frequencia = int(freq_str)
        
            
            codigo = ""
            
            while i < len(cadeia) and cadeia[i].isalpha():
                codigo += cadeia[i]
                i += 1
            
           
            while i < len(cadeia) and not cadeia[i].isalnum():
                i += 1
            
        
            if frequencia > 100:
                mensagem += codigo

    return mensagem[:100]  


cadeia = "90c87esd67uj,./';*&^120lin87uj101gu87km102a77jh150gem..&"
mensagem_extraida = extrair_mensagem(cadeia)
print("Mensagem transmitida acima de 100MHz:", mensagem_extraida)
