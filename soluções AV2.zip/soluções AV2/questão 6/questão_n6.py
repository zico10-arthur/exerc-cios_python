def inicializando_matriz(n):
    return[[0 for _ in range(n)]for _ in range(n) ]

def quadrado_magico(n):
    matriz = inicializando_matriz(n)
    i, j = 0, n // 2

    for num in range(1,n*n + 1):
        matriz[i][j] = num

        nova_i, nova_j = (i-1) % n , (j+1) % n 

        if matriz[nova_i][nova_j] != 0:
            i += 1
        else:
            i,j = nova_i,nova_j
    return matriz
def imprimir_matriz(matriz):
    for linha in matriz:
      print(" ".join(str(num).rjust(3) for num in linha))

def main():
    while True:
        n = int(input('digite as dimensões: '))
        if n % 2 == 0:
            print('digite um número impar')
        elif n < 3 or n > 15:
            print('digite um número entre 3 e 15: ')
        else:
            matriz = quadrado_magico(n)
            imprimir_matriz(matriz)
            opcao = str(input('[S/N]')).upper().strip()
            if opcao != 'S':
                break
if __name__ == "__main__":
    main()
