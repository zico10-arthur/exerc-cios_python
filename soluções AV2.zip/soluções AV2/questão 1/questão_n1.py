import gmpy2

print('CONJECTURA DE GOLDBACH')

def verificando_numero() -> int:
    while True:
        num = int(input('Digite um número par maior que 2 e menor que 4294967294: '))
        if num % 2 != 0:
            print('Digite um número par, por favor.')
        elif num < 2 or num > 4294967294:
            print('Por favor, digite um número válido.')
        else:
            return num  # Retorna o número válido

def lista_primos(num):
    return [gmpy2.mpz(i) for i in range(2, num + 1) if gmpy2.is_prime(i)]

def encontrar_soma(n, primos):
    for i in range(len(primos)):
        for j in range(i, len(primos)):
            if primos[i] + primos[j] == gmpy2.mpz(n):
                return primos[i], primos[j]
    return None

while True:
    # Obter um número válido do usuário
    num = verificando_numero()

    # Gerar a lista de números primos
    primos = lista_primos(num)

    # Encontrar os números primos cuja soma é igual a n
    resultado = encontrar_soma(num, primos)

    if resultado:
        print(f"Números primos que somam {num}: {resultado[0]}, {resultado[1]}")
    else:
        print(f"Não há dois números primos cuja soma seja {num}.")

    # Perguntar se o usuário quer continuar
    continuar = input("Você gostaria de testar outro número? (s/n): ").strip().lower()
    if continuar != 's':
        break

print("Obrigado por usar o programa!")
