print('Números de Kaprekar')

def erro(num: int) -> bool:
    """Verifica se o número é válido (maior que 0)."""
    if num < 1:
        print('Número inválido! Tente novamente.')
        return False
    return True

def dividir_numero(num: int):
    """Divide o número em duas partes e retorna as combinações possíveis."""
    num_str = str(num)
    for i in range(1, len(num_str)):  # Evita dividir no início ou no final
        parte1 = num_str[:i]
        parte2 = num_str[i:]
        
        parte1_int = int(parte1) if parte1 else 0
        parte2_int = int(parte2) if parte2 else 0
        
        yield parte1_int, parte2_int  # Gera pares de partes

def main():
    while True:
        try:
            num = int(input('Digite um número (ou -1 para sair): '))
            if num == -1:
                print("Saindo do programa.")
                break
            
            if not erro(num):
                continue
            
            kaprekar_encontrado = False

            for parte1_int, parte2_int in dividir_numero(num):
                soma = parte1_int + parte2_int
                
                if soma * soma == num:  # Verifica se o quadrado da soma é igual ao número original
                    print(f'Seu número {num} faz parte dos números de Kaprekar!')
                    kaprekar_encontrado = True
                    break
            
            if not kaprekar_encontrado:
                print(f'Seu número {num} não faz parte dos números de Kaprekar!')

        except ValueError:
            print('Por favor, digite um número válido.')

if __name__ == "__main__":
    main()
