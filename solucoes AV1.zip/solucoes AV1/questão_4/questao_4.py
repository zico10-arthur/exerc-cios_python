class Conta:
    def __init__(self, numero, senha):
        self.numero = numero
        self.saldo = 0.0
        self.senha = senha
        self.bloqueada = False
        self.extrato = []

    def depositar(self, valor):
        if valor > 0:
            self.saldo += valor
            self.extrato.append(f'Depósito: R$ {valor:.2f}')
            return True
        return False

    def sacar(self, valor):
        if 0 < valor <= self.saldo:
            self.saldo -= valor
            self.extrato.append(f'Saque: R$ {valor:.2f}')
            return True
        return False

    def transferir(self, valor, conta_destino):
        if self.sacar(valor):
            conta_destino.depositar(valor)
            self.extrato.append(f'Transferência: R$ {valor:.2f} para a conta {conta_destino.numero}')
            return True
        return False

    def consultar_extrato(self):
        return f'Saldo: R$ {self.saldo:.2f}\n' + '\n'.join(self.extrato)

    def bloquear(self):
        self.bloqueada = True

    def desbloquear(self):
        self.bloqueada = False


class Banco:
    def __init__(self):
        self.contas = {}

    def criar_conta(self, numero, senha):
        if numero not in self.contas:
            self.contas[numero] = Conta(numero, senha)
            return True
        return False

    def obter_conta(self, numero):
        return self.contas.get(numero)


def main():
    banco = Banco()

    while True:
        print("1. Criar conta")
        print("2. Acessar conta")
        print("0. Sair")
        opcao = input("Escolha uma opção: ")

        if opcao == '1':
            numero = input("Número da conta: ")
            senha = input("Senha da conta: ")
            if banco.criar_conta(numero, senha):
                print("Conta criada com sucesso!")
            else:
                print("Conta já existe!")

        elif opcao == '2':
            numero = input("Número da conta: ")
            conta = banco.obter_conta(numero)

            if conta is None:
                print("Conta não encontrada!")
                continue

            tentativas = 0
            while tentativas < 3:
                senha = input("Digite a senha: ")
                if conta.bloqueada:
                    print("Conta bloqueada! Dirija-se à boca do caixa.")
                    break
                if senha == conta.senha:
                    while True:
                        print("1. Depositar")
                        print("2. Sacar")
                        print("3. Transferir")
                        print("4. Consultar extrato")
                        print("0. Sair")
                        operacao = input("Escolha uma operação: ")

                        if operacao == '1':
                            valor = float(input("Valor do depósito: "))
                            if conta.depositar(valor):
                                print("Depósito realizado com sucesso!")
                            else:
                                print("Valor inválido.")

                        elif operacao == '2':
                            valor = float(input("Valor do saque: "))
                            if conta.sacar(valor):
                                print("Saque realizado com sucesso!")
                            else:
                                print("Saldo insuficiente ou valor inválido.")

                        elif operacao == '3':
                            numero_destino = input("Número da conta destino: ")
                            conta_destino = banco.obter_conta(numero_destino)
                            if conta_destino:
                                valor = float(input("Valor da transferência: "))
                                if conta.transferir(valor, conta_destino):
                                    print("Transferência realizada com sucesso!")
                                else:
                                    print("Saldo insuficiente ou valor inválido.")
                            else:
                                print("Conta destino não encontrada.")

                        elif operacao == '4':
                            print(conta.consultar_extrato())

                        elif operacao == '0':
                            break

                        else:
                            print("Operação inválida.")

                    break
                else:
                    tentativas += 1
                    print(f"Senha incorreta! Você ainda tem {3 - tentativas} tentativas.")

            if tentativas == 3:
                conta.bloquear()

        elif opcao == '0':
            break

        else:
            print("Opção inválida.")


if __name__ == "__main__":
    main()
