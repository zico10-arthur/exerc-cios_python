candidatos = {}
eleitores = {}
votos = {}

def registrar_candidatos():
    nome = input('Digite o seu nome para se candidatar: ')
    idade = int(input('Digite a sua idade: '))

    if idade >= 18:
        candidatos[nome] = idade
        print('Candidato registrado.')
    else:
        print('18 anos é a idade mínima.')

def registrar_eleitores():
    nome = input('Digite o seu nome para votar: ')
    idade = int(input('Digite a sua idade: '))

    if idade >= 16:
        if nome not in eleitores:
            eleitores[nome] = idade
            votos[nome] = None
            print(f'Eleitor {nome} registrado com sucesso.')
        else:
            print('Eleitor já registrado.')
    else:
        print('A idade mínima para votar é de 16 anos.')

def registrar_voto():
    nome = input('Digite seu nome para votar: ')

    if nome in eleitores:
        if votos[nome] is None:
            voto = input('Digite o nome do seu candidato, NULO para anular, ou BRANCO para branco: ').upper().strip()
            if voto in candidatos:
                votos[nome] = voto
                print(f'O {nome} votou no candidato {voto}.')
            elif voto.lower() == 'nulo':
                votos[nome] = 'Nulo'
                print('Voto registrado como nulo com sucesso.')
            elif voto.lower() == 'branco':
                votos[nome] = 'Branco'
                print('Voto registrado como branco.')
            else:
                print('Voto inválido.')
        else:
            print('Esse eleitor já votou.')
    else:
        print('Eleitor não registrado.')

def gerar_relatorio():
    total_votos = len(votos)
    votos_nulos = sum(1 for voto in votos.values() if voto == 'Nulo')
    votos_brancos = sum(1 for voto in votos.values() if voto == 'Branco')
    votos_validos = total_votos - votos_nulos - votos_brancos

    print("\n--- Relatório de Votação ---")
    print(f'Total de Votos: {total_votos}')
    print(f'Votos Nulos: {votos_nulos}')
    print(f'Votos em Branco: {votos_brancos}')
    print(f'Votos Válidos: {votos_validos}')

    contagem_candidato = {nome: 0 for nome in candidatos}
    for voto in votos.values():
        if voto in contagem_candidato:
            contagem_candidato[voto] += 1

    print(f'\nVOTOS POR CANDIDATO')
    for candidato, contagem in contagem_candidato.items():
        print(f'{candidato}: {contagem} votos')

def main():
    while True:
        print('''BEM VINDO AO COLÉGIO ELEITORAL, O QUE DESEJA FAZER?
              [1] Se candidatar
              [2] Registrar eleitor
              [3] Votar
              [4] Sair
              [5] Ver relatório''')
        opcao = int(input('Digite a sua opção: '))

        if opcao == 1:
            registrar_candidatos()
        elif opcao == 2:
            registrar_eleitores()
        elif opcao == 3:
            registrar_voto()
        elif opcao == 4:
            break
        elif opcao == 5:
            gerar_relatorio()
        else:
            print('Opção inválida, tente novamente.')

if __name__ == "__main__":
    main()
