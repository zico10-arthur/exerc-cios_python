import csv
from datetime import datetime, timedelta

class Livro:
    def __init__(self, titulo, autores, edicao, quantidade):
        self.titulo = titulo
        self.autores = autores
        self.edicao = edicao
        self.quantidade = quantidade

class Membro:
    def __init__(self, matricula, nome):
        self.matricula = matricula
        self.nome = nome
        self.locacoes = []
        self.total_multas = 0

    def alocar_livro(self, livro):
        if livro.quantidade > 0:
            data_locacao = datetime.now()
            data_devolucao = data_locacao + timedelta(days=15)
            livro.quantidade -= 1
            self.locacoes.append((livro, data_locacao, data_devolucao))
            return data_locacao, data_devolucao
        return None

    def devolver_livro(self, titulo, data_alocacao):
        for locacao in self.locacoes:
            if locacao[0].titulo.lower() == titulo.lower():
                data_devolucao = datetime.now()
                self.locacoes.remove(locacao)

                
                data_devolucao_esperada = data_alocacao + timedelta(days=15)
                atraso = (data_devolucao - data_devolucao_esperada).days
                livro = locacao[0]
                livro.quantidade += 1
                if atraso > 0:
                    multa = atraso * 10.00
                    self.total_multas += multa
                    return data_devolucao, multa
                return data_devolucao, 0
        return None, None

class Biblioteca:
    def __init__(self):
        self.livros = []
        self.membros = []

    def carregar_livros(self, arquivo):
        with open(arquivo, newline='', encoding='utf-8') as csvfile:
            leitor = csv.DictReader(csvfile)
            for linha in leitor:
                livro = Livro(linha['titulo'], linha['autores'], linha['edicao'], int(linha['quantidade']))
                self.livros.append(livro)

    def carregar_membros(self, arquivo):
        with open(arquivo, newline='', encoding='utf-8') as csvfile:
            leitor = csv.DictReader(csvfile)
            for linha in leitor:
                membro = Membro(linha['matricula'], linha['nome'])
                self.membros.append(membro)

    def buscar_livro(self, titulo):
        for livro in self.livros:
            if livro.titulo.lower() == titulo.lower():
                return livro
        return None

    def verificar_matricula(self, matricula):
        for membro in self.membros:
            if membro.matricula == matricula:
                return membro
        return None

    def quantidade_livros_disponiveis(self, titulo):
        livro = self.buscar_livro(titulo)
        if livro:
            return livro.quantidade
        return None

    def gerar_relatorio(self, data_inicio, data_fim):
        relatorio = []
        for membro in self.membros:
            alocacoes = [loc for loc in membro.locacoes if data_inicio <= loc[1] <= data_fim]
            total_atrasos = sum((datetime.now() - (loc[2] + timedelta(days=15))).days for loc in alocacoes if datetime.now() > loc[2] + timedelta(days=15))
            total_multas = membro.total_multas

            relatorio.append({
                'membro': membro.nome,
                'matricula': membro.matricula,
                'alocacoes': len(alocacoes),
                'atrasos': total_atrasos,
                'total_multas': total_multas
            })
        return relatorio


biblioteca = Biblioteca()
biblioteca.carregar_livros('livros.csv')
biblioteca.carregar_membros('membros.csv')

while True:
    
    matricula_usuario = input("Digite sua matrícula (ou 's' para sair): ")
    if matricula_usuario.lower() == 's':
        print("Sistema encerrado.")
        break

    membro = biblioteca.verificar_matricula(matricula_usuario)

    if membro:
        while True:
            opcao = input("Deseja alocar um livro (a), verificar quantidade de um livro (v), devolver um livro (d) ou gerar relatório (r)? (digite 's' para sair): ").lower()
            
            if opcao == 'a':
                titulo_livro = input("Digite o título do livro que deseja alugar: ")
                livro = biblioteca.buscar_livro(titulo_livro)

                if livro:
                    resultado = membro.alocar_livro(livro)
                    if resultado:
                        data_locacao, data_devolucao = resultado
                        print(f'{membro.nome} alocou o livro "{livro.titulo}" em {data_locacao.strftime("%d/%m/%Y")}.')
                        print(f'Data de devolução: {data_devolucao.strftime("%d/%m/%Y")}.')
                    else:
                        print(f'Não há exemplares disponíveis do livro "{livro.titulo}".')
                else:
                    print(f'Livro "{titulo_livro}" não encontrado.')

            elif opcao == 'v':
                titulo_livro = input("Digite o título do livro para verificar a quantidade disponível: ")
                quantidade = biblioteca.quantidade_livros_disponiveis(titulo_livro)
                if quantidade is not None:
                    print(f'Quantidade disponível do livro "{titulo_livro}": {quantidade}.')
                else:
                    print(f'Livro "{titulo_livro}" não encontrado.')

            elif opcao == 'd':
                titulo_livro_devolucao = input("Digite o título do livro que deseja devolver: ")
                while True:
                    data_alocacao_str = input("Digite a data da alocação (dd/mm/aaaa): ")
                    try:
                        data_alocacao = datetime.strptime(data_alocacao_str, "%d/%m/%Y")
                        break  
                    except ValueError:
                        print("Data inválida. Tente novamente no formato dd/mm/aaaa.")

                data_devolucao, multa = membro.devolver_livro(titulo_livro_devolucao, data_alocacao)

                if data_devolucao is not None:
                    if multa > 0:
                        print(f'Membro {membro.nome} devolveu o livro "{titulo_livro_devolucao}" em {data_devolucao.strftime("%d/%m/%Y")} com multa de R$ {multa:.2f}.')
                    else:
                        print(f'Membro {membro.nome} devolveu o livro "{titulo_livro_devolucao}" em {data_devolucao.strftime("%d/%m/%Y")} sem multa.')
                else:
                    print(f'O livro "{titulo_livro_devolucao}" não estava alugado por {membro.nome}.')

            elif opcao == 'r':
                data_inicio_str = input("Digite a data de início do relatório (dd/mm/aaaa): ")
                data_fim_str = input("Digite a data de fim do relatório (dd/mm/aaaa): ")
                try:
                    data_inicio = datetime.strptime(data_inicio_str, "%d/%m/%Y")
                    data_fim = datetime.strptime(data_fim_str, "%d/%m/%Y")
                    relatorio = biblioteca.gerar_relatorio(data_inicio, data_fim)

                    print("\nRelatório de Alocações e Devoluções:")
                    for item in relatorio:
                        print(f'Membro: {item["membro"]} (Matrícula: {item["matricula"]})')
                        print(f'  Alocações: {item["alocacoes"]}')
                        print(f'  Atrasos: {item["atrasos"]}')
                        print(f'  Total de Multas: R$ {item["total_multas"]:.2f}\n')

                except ValueError:
                    print("Uma ou mais datas estão inválidas. Tente novamente.")

            elif opcao == 's':
                print("Saindo do sistema para nova matrícula.")
                break
            
            else:
                print("Opção inválida. Tente novamente.")
    else:
        print("Matrícula inválida. Você não pode alugar livros.")
