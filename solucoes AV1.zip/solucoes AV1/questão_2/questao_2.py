def conversor_romano_decimal(romano):
    valores_romano = {
        'I': 1,
        'V': 5,
        'X': 10,
        'L': 50,
        'C': 100,
        'D': 500,
        'M': 1000
    }
    total = 0
    primeiro_valor = 0
    for letra in reversed(romano):
        valor = valores_romano[letra]
        if valor < primeiro_valor:
            total -= valor
        else:
            total += valor
        primeiro_valor = valor
    return total

def conversor_decimal_romano(decimal):
    valores_decimal = [
        (1000, 'M'),
        (900, 'CM'),
        (500, 'D'),
        (400, 'CD'),
        (100, 'C'),
        (90, 'XC'),
        (50, 'L'),
        (40, 'XL'),
        (10, 'X'),
        (9, 'IX'),
        (5, 'V'),
        (4, 'IV'),
        (1, 'I')
    ]
    resultado = ''
    for valor, romano in valores_decimal:
        while decimal >= valor:
            resultado += romano
            decimal -= valor
            
    return resultado

def validação_de_decimal(decimal):
     return 1 <= decimal <= 3999
def validar_romano(romano):
    return 'I' <= romano <= 'MMMCMXCIX'

def opção_de_conversão():
    print('''Opção [1] Decimal para Romano
Opção [2] Romano para Decimal''')
    
    opção = input('Você deseja converter a opção 1 ou opção 2: ')
    
    if opção == '1':
        decimal = int(input('Digite seu número decimal: '))
        if validação_de_decimal(decimal):
         print(f'{decimal} em romano é {conversor_decimal_romano(decimal)}')
        else:
         print('Número inválido. Por favor, insira um número entre 1 e 3999.')
    elif opção == '2':
        romano = input('Digite o seu número romano: ').strip().upper()
        if validar_romano(romano):
         print(f'{romano} em decimal é {conversor_romano_decimal(romano)}')
        else:
         print('Número inválido. Por favor, insira um número entre I e MMMCMXCIX..')
    else:
        print('Opção inválida!')


if __name__ == "__main__":
    opção_de_conversão()
