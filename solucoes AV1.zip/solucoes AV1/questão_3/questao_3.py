from typing import Tuple

def número_de_jogadores() -> int:
    while True:
        try:
            jogadores = int(input('Quantos jogadores desejam jogar a FORCA? : '))
            if jogadores < 2:
                print('Você precisa de pelo menos 2 jogadores para a FORCA.')
            else:
                return jogadores
        except ValueError:
            print('Por favor, insira um número válido.')

def escolher_palavra() -> Tuple[str, str]: 
    palavra = input('Jogador 1, escolha a palavra para a forca: ').strip().lower()
    dica = input('A dica é: ').strip()
    return palavra, dica

def desenhar_forca(tentativas: int):
    estados = [
        """
           -----
           |   |
           |   O
           |  /|\\
           |  / \\
           |
        """,
        """
           -----
           |   |
           |   O
           |  /|\\
           |  /
           |
        """,
        """
           -----
           |   |
           |   O
           |  /|
           |
           |
        """,
        """
           -----
           |   |
           |   O
           |   |
           |
           |
        """,
        """
           -----
           |   |
           |   
           |
           |
           |
        """,
        """
           -----
           |   |
           |   
           |
           |
           |
        """,
        """
           -----
           |   |
           |
           |
           |
           |
        """
    ]
    
    print(estados[tentativas])

def calcular_pontos(tentativas_restantes: int, dificuldade: int) -> int:
    return tentativas_restantes * dificuldade

def jogo_da_forca():
    jogadores = número_de_jogadores()
    ranking = [0] * jogadores
    rodadas = 1
    
    while True:
        print(f'\n--- Rodada {rodadas} ---')
        palavra, dica = escolher_palavra()
        dificuldade = len(palavra) 
        tentativas = 6 
        letras_adivinhadas = []
        jogador_atual = 1 
        
        while tentativas > 0:
            print(f"\nDica: {dica}")
            print("Palavra: ", end="")
            for letra in palavra:
                if letra in letras_adivinhadas:
                    print(letra, end=" ")
                else:
                    print("_", end=" ")
            print("\n\nLetras adivinhadas: ", letras_adivinhadas)

            letra = input(f"Jogador {jogador_atual}, adivinhe uma letra: ").strip().lower()
            
            if letra in letras_adivinhadas:
                print("Você já adivinhou essa letra.")
            elif letra in palavra:
                letras_adivinhadas.append(letra)
                print("Boa! A letra está na palavra.")
            else:
                tentativas -= 1
                letras_adivinhadas.append(letra)
                print(f"Ops! A letra não está na palavra. Tentativas restantes: {tentativas}")
                desenhar_forca(tentativas)

            if all(letra in letras_adivinhadas for letra in palavra):
                print(f"Parabéns, Jogador {jogador_atual}! Você adivinhou a palavra: {palavra}")
                pontos = calcular_pontos(tentativas, dificuldade)
                ranking[jogador_atual - 1] += pontos
                break
        else:
            print(f"Você perdeu! A palavra era: {palavra}")

        rodadas += 1
        print("\n--- Ranking ---")
        for i in range(jogadores):
            print(f"Jogador {i + 1}: {ranking[i]} pontos")

        continuar = input("Desejam jogar outra rodada? (s/n): ").strip().lower()
        if continuar != 's':
            break


jogo_da_forca()
