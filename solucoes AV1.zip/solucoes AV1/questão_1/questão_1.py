from random import choice

def letras_na_palavra(tentativa, palavra):
    
    return [letra for letra in palavra if letra in tentativa]

def indice_na_palavra(tentativa, palavra):
    
    return [i for i, letra in enumerate(palavra) if letra in tentativa]

def jogo_de_adivinhacao():
    tentativas = 0
    lista = ["celular", "computador", "teclado", "mouse"]
    computador = choice(lista)
    num_letras = len(computador)

    print(f'A palavra tem {num_letras} letras e é sobre tecnologia.')

    while tentativas < 5:
        adv = input('Adivinhe a palavra: ').strip().lower()
        tentativas += 1

        if adv == computador: 
            print('Parabéns! Você ganhou o jogo!')
            break
        else:
            letras_corretas = letras_na_palavra(adv, computador)
            print(f'As letras que você digitou e estão na palavra: {", ".join(letras_corretas)}')

            indices_corretos = indice_na_palavra(adv, computador)
            print(f'Os índices corretos na palavra são: {", ".join(map(str, indices_corretos))}')
        
        if tentativas == 5:
            print(f'Você esgotou suas tentativas. A palavra era "{computador}".')

if __name__ == "__main__":
    jogo_de_adivinhacao()
